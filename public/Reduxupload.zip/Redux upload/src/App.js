import './App.css';
import Test from './Test';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Home';
import SingleProduct from './SingleProduct';
import Header from './Header';
function App() {
  const arry = [
    {  id: 1,
      name: "mohammad"    
    },
    {  id: 2,
      name: "hasnain"    
    },
    {      id: 3,
      name: "kou"
    },
  ];
  return ( 
    <BrowserRouter>
    <Header />
    <Routes>
      <Route path="/" element={<Home vari={arry} />} />
      <Route path="/test" element={<Test />} />
      <Route path="/singleproduct/:id" element={<SingleProduct vari={arry} />} />
    </Routes>
  </BrowserRouter>
  );
}
export default App;
