import React from 'react'
import { NavLink } from 'react-router-dom';

const Header = () => {
  return (
    <div>
            <NavLink to="/" className="textdece topnav">Home</NavLink>
            <NavLink to="/test" className="textdece topnav">Test</NavLink>

    </div>
  )
}

export default Header;