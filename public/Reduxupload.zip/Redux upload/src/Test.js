import React from 'react'

const Test = () => {


  const arry = ["one","two","three", ] ;

  return (
    <div>Test</div>
  )
}

export default Test;