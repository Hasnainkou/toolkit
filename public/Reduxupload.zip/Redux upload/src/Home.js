import React from 'react'
import { NavLink } from 'react-router-dom';

const Home = (props) => {

const arry = props.vari ;

  return (
    <div>

      {arry.map((e, id) => (
     <div key={id}>     
        <NavLink to={`/singleproduct/${e.name}`} className="Navlink"   >
          {e.name}
        </NavLink> <br /> 
        </div>

      ))}




    </div>
  )
}

export default Home;