import React from 'react'
import { useParams } from 'react-router-dom';

const SingleProduct = (props) => {
  const arry = props.vari;

  const id = useParams();

  let updatedCart = arry.filter(
    (curItem) => curItem.name == id.id
  );

  return (
    <div><p>{updatedCart[0].name} </p> <br /> {updatedCart[0].id}</div>
  )
}

export default SingleProduct;