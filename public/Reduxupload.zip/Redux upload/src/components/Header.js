import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import { DLT, TOGGLE } from "../redux/actions/action";
import { useDispatch } from 'react-redux';

const Header = () => {
    const [price, setPrice] = useState(0);
    const [totalitem, setTotalitem] = useState(0);
   
    const getdata = useSelector((state) => state.cartreducer.carts);
    const getdat = useSelector((state) => state.cartreducer.toggles);
    const dispatch = useDispatch();

    const deletee = (e) => {
        dispatch(DLT(e));
    }

    const toggless = (e) => {
        dispatch(TOGGLE(e));
    }

    const arry = [100, 500, 900]
    const total = () => {
        let price = 0;
        arry.map((ele) => {
            price = ele + price
        });
        setPrice(price);
    };
console.log(price);
    const totalitemss = () => {
        let prices = 0;
        getdata.map((ele) => {
            prices = ele.amountt + prices
        });
        setTotalitem(prices);
    };

 

    useEffect(() => {
        totalitemss();
    }, [totalitemss]);

    useEffect(() => {
        total();
    }, [total]);

    return (
        <div> <h3> Bismillah </h3>
            <NavLink to="/">
                <div>Home</div></NavLink>

       <div> Total Item in Cart : {totalitem}</div>
            <button onClick={() => toggless(getdat)}>TOGGLE</button>


            {getdat && (

                <div>
                    <div className="acticess">   {getdata.map((e, id) => (
                        <div key={id} style={{ border: "2px solid red" }}>
                                 <div className="cards-header"> Item: {e.amountt}</div>
                            <NavLink to={`/cart/${e.id}`}> Item:  {e.rname}  Price:  {e.price} </NavLink>
                            <button onClick={() => deletee(e.id)}>DELETE ITEM</button>
                        </div>
                    ))}</div>
                    <div>Total Price : {price} </div></div>
            )}

        </div>
    );
};

export default Header;