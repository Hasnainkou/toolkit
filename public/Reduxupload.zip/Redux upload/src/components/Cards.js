import React, { useState } from 'react';
import CardData from './CardData';
import { useDispatch } from 'react-redux';
import { ADD } from '../redux/actions/action';

const Cards = () => {
  const [data, setData] = useState(CardData);

  const dispatch = useDispatch();

  const send = (e) => {
dispatch(ADD(e));
  }
  return (
    <div>
      {data.map((e, id) => (<div key={id} style={{ width: "30%", float: "left", border:"1px solid red", height:"500px", margin:"20px" }}>      <div>    Name : <h3>{e.rname}</h3>  <br /> Price: {e.price} . </div>
        <img src={e.arrimg} alt="go" style={{ width: "200px" }} />
        <button
        onClick={()=>send(e)}
        > ADD TO CART</button>
      </div>
      ))}
    </div>
  )
}

export default Cards;