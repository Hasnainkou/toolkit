const CardData = [
{
    id: 1,
    rname: "Masala Dosa",
    price: 150,
    rating: "3.9",
    arrimg: "https://media-cdn2.greatbritishchefs.com/media/cqfbszpf/pali-hill0064-selects.whqc_1536x1024q80.webp"
},
{
    id: 2,
    rname: "Maggi",
    price: 20,
    rating: "4.9",
    arrimg: "https://www.nestleprofessional.in/sites/default/files/2022-08/MAGGI-Noodles-Chakna-756x471.webp"
},
{
    id: 3,
    rname: "Samosa",
    price: 80,
    rating: "3.5",
    arrimg: "https://as2.ftcdn.net/v2/jpg/05/11/08/05/1000_F_511080597_NvqjRdezlARSQHy4VpAKFvUVTEeGdlLy.jpg"
},
{
    id: 4,
    rname: "Chat",
    price: 50,
    rating: "3.9",
    arrimg: "https://www.cookwithmanali.com/wp-content/uploads/2020/05/Masala-Dosa-1014x1536.jpg"
},
{
    id: 5,
    rname: "Biryani",
    price: 440,
    rating: "3.9",
    arrimg: "https://www.cookwithmanali.com/wp-content/uploads/2020/05/Masala-Dosa-1014x1536.jpg"
},
{
    id: 6,
    rname: "Pao Bhaji",
    price: 150,
    rating: "3.9",
    arrimg: "https://www.cookwithmanali.com/wp-content/uploads/2020/05/Masala-Dosa-1014x1536.jpg"
},
];

export default CardData;