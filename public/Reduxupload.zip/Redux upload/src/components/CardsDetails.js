import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import { useSelector } from "react-redux";
import { DLT } from "../redux/actions/action";
import { useDispatch } from 'react-redux';

const CardsDetails = () => {
  const [data, setData] = useState([])
  const getdata = useSelector((state) => state.cartreducer.carts);
  const dispatch = useDispatch();
  const { id } = useParams();

  const compare = () => {
    let updatedCart = getdata.filter((curItem) => { return curItem.id == id });
    setData(updatedCart);
  }

  const history = useNavigate();
 
  useEffect(() => {
    compare();
  }, [id]);

  const deletee = (e) => {
    dispatch(DLT(e));
    history("/");
  }

  return (
    <div style={{ border: "2px solid blue" }}>
 
      {data.map((user, id) => (<div key={id}>  
         <div className="user">{user.rname}</div>
         <div className="user">{user.amountt}</div>
        <button onClick={() => deletee(user.id)}>DELETE ITEM</button>
      </div>
      ))}

    </div>
  )
}

export default CardsDetails;