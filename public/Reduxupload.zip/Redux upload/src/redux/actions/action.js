
export const PRO = (items) => {
    return {
        type: "ADD_ALL",
        payload: items
    }
}

export const SRT= () => {
    return {
        type: "SRT_ALL",
        // payload: items
    }
}

export const SRTTWO= () => {
    return {
        type: "SRT_ALL_TWO",
        // payload: items
    }
}

export const CHAGNE_INPUT_VALUE = 'CHANGE_INPUT_VALUE';
export const changeInputValue = (value) => ({type: CHAGNE_INPUT_VALUE, payload: value})


export const ONCHANG= (vlu) => {
    return {
        type: "ON_CHANG",
        payload: vlu
    }
}



export const ADD = (item) => {
    return {
        type: "ADD_CART",
        payload: item
    }
}
export const DLT = (id) => {
    return {
        type: "RMV_CART",
        payload: id
    }
}

export const TOGGLE = (id) => {
    return {
        type: "TOGGLE_CART",
        payload: id
    }
}
