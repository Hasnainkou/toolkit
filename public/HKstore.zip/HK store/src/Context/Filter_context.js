 import { createContext, useContext, useEffect, useReducer } from "react";
 import reducer from "../reducer/FilterReducre";
 import { useProductContext } from "./ProductContext";

 const FilterContext = createContext();

const intialState = {
    filter_products: [],
    all_products: [],
    sorting_value: "",
    filters: {
        text: "",
        category: "all",
      },
};

 export const FilterContextProvider = ({children}) => {
    const { products} = useProductContext();
     const [state, dispatch] = useReducer(reducer, intialState);

  // sorting function
  const sorting = (event) => {
    let userValue = event.target.value;
    dispatch({ type: "GET_SORT_VALUE", payload: userValue });
  };

  // update the filter values
  const updateFilterValue = (event) => {
    let name = event.target.name;
    let value = event.target.value;

    return dispatch({ type: "UPDATE_FILTERS_VALUE", payload: { name, value } });
  };

  // to clear the filter
  const clearFilters = () => {
    dispatch({ type: "CLEAR_FILTERS" });
  };

useEffect(()=>{
    dispatch({ type: "FILTER_PRODUCTS" });
    dispatch({ type: "SORTING_PRODUCTS"});
},[products, state.sorting_value, state.filters]);

    useEffect(()=>{
        dispatch({type: "LOAD_FILTER_PRODUCTS", payload: products})
    },[products]);

    return ( 
    <FilterContext.Provider value={{...state,  sorting, updateFilterValue, clearFilters }}>
        {children}
     </FilterContext.Provider>);
 };

export const useFilterContext = () => {
 return   useContext(FilterContext);
}