import { NavLink } from "react-router-dom";
import "./App.css";
import "./cssstyle.css";
import Star from "./components/Star";
import FilterSection from "./components/FilterSection";
import { useFilterContext } from "./Context/Filter_context";

 
const Products = () => {
  const { filter_products, filters: { text }, updateFilterValue } = useFilterContext();

  console.log(filter_products);


  return (<>
  
  {/* Search Box  */}
   <div className="searchbox">
    <form onSubmit={(e) => e.preventDefault()} className="searchboxoutput">
      <input
        type="text"
        name="text"
        placeholder="Search for products, brands and more"
        value={text}
        onChange={updateFilterValue}
        className="searchboxinput"
      />
    </form>
    </div>
  {/* Search Box  */}

    <div className="products-main">

      <FilterSection />
      <div className="productsdivwarper">
        {filter_products.map((curel) => {
          return (
            <div className="Materdiv" key={curel.id}>
              <NavLink to={`/singleproduct/${curel.id}`} className="Navlink"   >
                <div className="childdiv" id="demo1" >
                  <div className={(curel.price > 40 ? "off" : "dectiva")}>20% Off</div>

                  {/* image div start */}
                  <div className="imgdiv">
                    <div className="imgdivproduct">
                      <div style={{
                        backgroundImage:
                          `url(${curel.image})`, backgroundSize: "contain", backgroundPosition: 'center', backgroundRepeat: 'no-repeat',
                      }} className="test">
                      </div>
                    </div>
                  </div>
                  {/* image div End */}

                  <div className="divh5">
                    <h5 >{curel.title}</h5></div>

                  <div className="displcenter">
                    <div className="flexinlinee" >
                      <div> <p className="divprice"> ₹{curel.price > 40 ? curel.price - (curel.price / 10).toFixed(2) : curel.price} </p> </div>
                      <div className={(curel.price > 40 ? "divh22" : "dectiva")}>
                        <del >M.R.P. ₹{curel.price}</del> </div></div>
                  </div>
                  <Star stars={curel.rating.rate} reviews={curel.rating.count} />
                </div>
              </NavLink>
            </div>)
        })} </div>
    </div>
  </>);
};


export default Products;
