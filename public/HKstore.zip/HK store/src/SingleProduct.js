import React, { useEffect, useState } from "react";
import { NavLink, useParams } from "react-router-dom";
import { useProductContext } from "./Context/ProductContext";
import "./singlecss.css";
import { MdSecurity } from "react-icons/md";
import { TbTruckDelivery, TbReplace } from "react-icons/tb";
import Cartamounttoggle from "./components/Cartamounttoggle";
import AddToCart from "./components/AddToCart";
import RealAddtocart from "./components/RealAddtocart";

const API = 'https://fakestoreapi.com/products/'

const SingleProduct = () => {
    const [amount, setAmount] = useState(1);

    const setIncrease = () => {
        setAmount(amount + 1);
    };
    const setDecrease = () => {
        amount > 1 ? setAmount(amount - 1) : setAmount(1);
    };

    const { getSingleProduct, isSingleLoading, singleProduct } = useProductContext();

    const { price, rating } = singleProduct;
    const { id } = useParams();
    const myStyle = {
        backgroundImage:
            `url(${singleProduct.image})`,
        backgroundSize: "contain",
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
    };

    useEffect(() => {
        getSingleProduct(`${API}${id}`)
    }, []);
    if (isSingleLoading) {
        return <div className="singleproductloading"> <div> Loading......</div></div>
    }
    return (<>
        <div className="sglwarper">
            <div className="sglmaindiv">
                <div className="flexdisp sglnavg">
                    <NavLink to="/" className="sglNavlink44">Home</NavLink> <span className="sglspansls">/</span>
                    <span >{singleProduct.category}</span>
                </div>
                <div className="sgldesctiptionnimg">
                    <div className="sglfirstdiv"> <div>
                        <div className="sglimgdiv" style={myStyle}>
                        </div>
                        <div className="sglmgtop">
                            {/* <div className="sgladdtocart" > <span className="sglspanaddtocart">  <FiShoppingCart /></span> ADD TO CART</div> */}
                            <RealAddtocart product={singleProduct} amount={amount} />
                            <AddToCart product={singleProduct} amount={amount} />
                        </div>
                    </div>
                    </div>
                    {/* discription div start  */}
                    <div className="sglsecondiv">
                      <div> <div className="sgltitle">{singleProduct.title}</div></div> 
                        {/* <Starforsingle star={rating.rate} /> */}
                        <div className="sglflexdisp">
                            <p className="sglprice"> ₹{price > 40 ? price - (price / 10).toFixed(2) : price}</p>

                            <div className={(price > 40 ? "sgldivh2244" : "sgldectiva")}>
                                <del className="sgldel">M.R.P. ₹{price}</del>
                                <span className="sglspanoff">20% Off</span> </div>
                        </div>

                        <div className="sgldiscrip">
                            <p className="sgldiscp1"> Description : </p>
                            <p className="sgldiscp2">
                                {singleProduct.description}
                            </p>
                        </div>

                        <div className="sgldeleverydetails">
                            <div className="sglfreedelevery">  <TbTruckDelivery className="warranty-icon" />  <div className="sgl-font"> Free Delivery </div></div>
                            <div className="sglreplacment"> <div></div> <TbReplace className="warranty-icon" /> <div className="sgl-font"> 30 Days  Replacement </div></div>
                            <div className="sgldeverd"> <TbTruckDelivery className="warranty-icon" /> <div className="sgl-font"> Hk Delivered </div></div>
                            <div className="sglwarenty"> <MdSecurity className="warranty-icon" /> <div className="sgl-font">2 Year Warranty </div> </div>
                        </div>




                        <div className="cartamounttoggle">
                            <Cartamounttoggle amount={amount} setIncrease={setIncrease} setDecrease={setDecrease} /></div>

  

                    </div>
                    {/* discription div end */}

                </div>
            </div>
        </div>

    </>);
}

export default SingleProduct;
