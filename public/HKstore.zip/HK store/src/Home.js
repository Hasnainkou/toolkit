import React from "react";
import FeatureProduct from "./components/FeatureProduct";
import "./cssstyle.css"
import { NavLink } from "react-router-dom";
import { FiShoppingCart } from "react-icons/fi";
import { useFilterContext } from "./Context/Filter_context";

const Home = () => {
    const { updateFilterValue } = useFilterContext();


    const electronics = {
        backgroundImage:
            `url(./images/electronics.jpg)`,
        backgroundSize: "contain",
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        with: "250px",
    };
    const jewelery = {
        backgroundImage:
            `url(./images/jewllary.jpg)`,
        backgroundSize: "contain",
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        with: "250px",
    };
    const women = {
        backgroundImage:
            `url(./images/Capture.jpg)`,
        backgroundSize: "contain",
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        with: "250px",
    };
    const men = {
        backgroundImage:
            `url(./images/boyr.jpg)`,
        backgroundSize: "contain",
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        with: "250px",
    };
    return (
        <>

            <div className="homeimgdiv">
                <img src="./images/cart_8.jpg" alt="Navlinkk" className="logoss" />
                <img src="./images/13833.jpg" alt="Navlinkk" className="logoss2" />
                <div className="homeimgabsolut">
                    <NavLink to="/products" className="hhomenav">   <div className="homeaddtocart1"    >
                        <span className="sglspanaddtocart">  <FiShoppingCart /></span> SHOP NOW </div>
                    </NavLink>
                </div>
            </div>


            <div className="homeTodaysdeal"><p className="homeTodaysdealp"> Today’s Best Deals 💥</p>
                <NavLink to="/products">
                    <p className="homeTodaysdealpviewall">View All Deals</p></NavLink>
            </div>


            <div className="homefeturdivv">
            <FeatureProduct /></div>


            <div className="homefeturdivv">
            <div className="homeFeaturedCategories">Featured Categories</div></div>


            {/* Featured Categories */}


            <div className="homefetuerd">
          

                <div className="homefetmain">


                    {/* "jewelery" */}
                    <div className="homefeturemaindiv">
                        <NavLink to="products">
                            <button
                                type="button"
                                name="category"
                                value="jewelery"
                                onClick={updateFilterValue} className="homebuttons" style={jewelery}>
                                {/* <img src="./images/jewllary.jpg" alt="no" className="homejewllary"/>
                 <div className="homefeturetext">  Jewellery </div> */}
                            </button>
                        </NavLink>
                    </div>


                    {/* "electronics" */}
                    <div className="homefeturemaindiv" >
                        <NavLink to="products" >
                            <button
                                type="button"
                                name="category"
                                value="electronics"
                                onClick={updateFilterValue}
                                className="homebuttons" style={electronics}>

                            </button>

                        </NavLink>
                    </div>




                    {/* "women's clothing" */}
                    <div className="homefeturemaindiv">
                        <NavLink to="products">
                            <button
                                type="button"
                                name="category"
                                value="women's clothing"
                                onClick={updateFilterValue} className="homebuttons" style={women}>
                                {/* <img src="./images/Capture.jpg" alt="no" className="homejewllary"/>
                    <div className="homefeturetext">   Women's clothing</div> */}
                            </button>
                        </NavLink>
                    </div>


                    {/* "men's clothing" */}
                    <div className="homefeturemaindiv" >
                        <NavLink to="products">
                            <button
                                type="button"
                                name="category"
                                value="men's clothing"
                                onClick={updateFilterValue} className="homebuttons" style={men}>
                                {/* <img src="./images/boyr.jpg" alt="no" className="homejewllary"/>
                      <div className="homefeturetext">  Men's clothing</div> */}
                            </button>
                        </NavLink>
                    </div>
                </div>
            </div>
            {/* Featured Categories */}











    
        </>
    );



}

export default Home;