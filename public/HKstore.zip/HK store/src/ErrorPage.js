import React from "react";

const ErrorPage = () =>{

return (
<h1>Error Please try again</h1>

);

}

export default ErrorPage;