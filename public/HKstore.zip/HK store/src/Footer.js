import React from "react";

import "./cssstyle.css"
import { NavLink } from "react-router-dom";
import { FiPhoneCall } from "react-icons/fi";
import { AiOutlineMail } from "react-icons/ai";
import { BiMap, BiUpArrowCircle } from "react-icons/bi";
import { FaRegHandPointRight } from "react-icons/fa";


const Footer = () => {
  return (
    <>
      <div className="footermainwarper">
        <div className="footermain">

          <div className="footerfirst">
            <h3>Links</h3>
            <NavLink to="/about" className="footernavlink">  <p>About </p></NavLink>
            <NavLink to="/Products" className="footernavlink">  <p>Products </p></NavLink>
            <NavLink to="/Contact" className="footernavlink">  <p>Contact </p></NavLink>
            <NavLink to="/Cart" className="footernavlink">  <p>Cart </p></NavLink>

          </div>
          <div className="footersecond">
            <h3>About This Website</h3>
            <p><FaRegHandPointRight /> Redux </p>
            <p><FaRegHandPointRight /> API Based </p>
            <p><FaRegHandPointRight /> Dynamic </p>
            <p><FaRegHandPointRight /> Responsive </p>

          </div>
          <div className="footertherd">
            <h3 className="thirdcontact">Contact </h3>
            <div className="footercontactall" >
              <FiPhoneCall /> +91-9009390297 <br />
              <AiOutlineMail /> hasnainkousar@gmail.com   <br />
              < BiMap /> House No. A-499, Housing   <br />
              Board Colony, Aishbagh, Bhopal   <br />
              MP 462008, India   <br />

            </div>
         

          </div>


          <div className="footerbacktotop">
            <div
              onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="kreep">
              <button className="button button5">Top <BiUpArrowCircle className="footerarrow" /></button>
            </div>
          </div>
          {/* back to tp */}
        </div>
      </div>
      <div className="footermainwarpersecond"><p>All rights reserved © 2019-2023 hasnain-store.netlify.app/</p></div>
    </>
  );



}

export default Footer;