import React from "react"; 
import { FaRegHandPointRight } from "react-icons/fa";
import { BsDot } from "react-icons/bs";
 
const About = () =>{
return(
<div className="aboutmain">
  <div className="aboutwarper">
    <h3>About This Website</h3> 
    <p><FaRegHandPointRight/> Built on React.Js</p>
    <p><FaRegHandPointRight/> Redux</p>
    <p><FaRegHandPointRight/> API Based </p>
    <p><FaRegHandPointRight/> Dynamic </p>
    <p><FaRegHandPointRight/> Responsive</p>
    <p><FaRegHandPointRight/> Used Methods</p>
    <div> <BsDot className="bsdot"/> Reduce</div>
    <div> <BsDot className="bsdot"/> Filter</div>
    <div> <BsDot className="bsdot"/> Map etc.</div>
    </div>
    </div>
);
 }

export default About;