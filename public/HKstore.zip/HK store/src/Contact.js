import React from "react";
import "./cssstyle.css";
import { FiPhoneCall } from "react-icons/fi";
import { AiOutlineMail } from "react-icons/ai";
import { BiMap } from "react-icons/bi";
import { BsDownload } from "react-icons/bs";

const Contact = () => {
  return (
    <>
      <div className="contactmainwarper">
        <div className="contactmaincontaner">
          <div className="contactsspecebtwen">
            <div className="contacdetails">
              <div className="contactname">Hasnain Kousar </div>
              <div className="contactweb">(Web Developer)</div>
              <div className="contactall" ><FiPhoneCall /> +91-9009390297 <br /> <AiOutlineMail /> hasnainkousar@gmail.com
                <br /> < BiMap /> Bhopal, India
              </div>
            </div>
            <div className="contactimg"> <img src="./images/hk.jpg" alt="" />



              <a href="/images/UpdatedResume.pdf" download>
                <div className="conteactbutnow"> <span className="conteactspanbuynow">
                  < BsDownload />
                </span> Download Resume</div>
              </a>



            </div>


          </div>
          <div style={{ textAlign: "center" }}>
            <h3 className="conteactaboutmyself" style={{ marginBottom: "30px", marginTop: "50px" }}>
              <i > CURRICULUM VITAE</i></h3>
            <h4 style={{ marginBottom: "-10px" }}>Profile summary </h4>
            <ul>
              <li>Experience in IT 2.5+ Years.</li>
              <li> <b> React.js</b> Developer 1+ Year.</li>
            </ul>

            <h4 style={{ marginTop: "50px", marginBottom: "-10px" }}>Career Objective </h4>
            <p>Creative and technical web development professional with 2.5+ year of experience looking for a position where I can enhance my knowledge of design and development principles and grow with the organization.
            </p>

            <h4 style={{ marginTop: "70px", marginBottom: "-10px" }}>WORK EXPERIENCE </h4>
            <h5> Web Developer</h5>
            <h3 style={{ color: "#3577f0", marginTop: "-10px" }}>Infusai Solutions Private Limited</h3>
            <p> 20th June 2022 – 30th July 2023 (1 Year 1 month)  </p>

            <ul>
              <li>	Designed and developed web applications using JavaScript frameworks React.js and Angular.js to increase target audience engagement.</li>
              <li>Developed user interfaces with modern JavaScript frameworks, HTML5, and CSS3, which improved user satisfaction.</li>
              <li> Developed documentation to teach new team members company standards and best practices in React.js and Angular.js.</li>
              <li> Created accessible, responsive, and functional user interfaces to allow visitors on any device to have the same perfect user experience.</li>
            </ul>




            <h5 style={{ marginTop: "70px", marginBottom: "-10px" }}> Frontend Developer</h5>
            <h4>Freelancer Consultant </h4>
            <p>  July 2021 – May 2022 (10 months)  </p>

            <ul>
              <li>	Created the user experience that fetched, parsed, and formatted analytic data, and relayed it into React components. </li>
              <li> Employed version-control software to test, track and update existing code.</li>
              <li>  Preformed comprehensive unit tests to ensure compatibility across multiple web browsers</li>
              <li> Identify solutions to technical issues to enhance website functionality.</li>
            </ul>
            <h3 style={{ marginTop: "70px", marginBottom: "-10px" }}>Skill and Experiences</h3>

            <ul>
              <li> <b> React.js </b> </li>
              <li> <b> Redux </b> </li>
              <li> <b>  JavaScript </b></li>
              <li>HTML5</li>
              <li>CSS3</li>
              <li>Bootstrap</li>
              <li>Github/GitLab</li>
            </ul>

            <p> Other Language and framework.</p>

            <ul>

              <li>Basics of Angular.Js, Figma, Material UI.</li>
        
            </ul>

          </div>
        </div>
      </div>

    </>
  )
}
export default Contact;
