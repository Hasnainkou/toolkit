
const INIT_STAT = {
  products: [],
  filterproducts: [],
  carts: [],
  toggles: true,
  value: "",
}

export const cartreducer = (state = INIT_STAT, action) => {
  switch (action.type) {

    case "ADD_ALL":      
      return {
        ...state,
     products: action.payload,
     filterproducts: action.payload
      }


      case 'CHANGE_INPUT_VALUE':
        return{
          ...state,
          value: action.payload
        }


      case "SRT_ALL":    
      const newSrt = state.products.filter((curItem) => curItem.id > 10);
      return {
        ...state,
        filterproducts: newSrt
      }

 
      case "ON_CHANG":    
      // const onCHang = state.products.filter((curItem) => curItem.id > 10);

    let  tempFilterProduct = state.products.filter((curElem) => {
        return curElem.title.toLowerCase().includes(action.payload);
      });

      return {
        ...state,
        filterproducts: tempFilterProduct
      }

      case "SRT_ALL_TWO":    
      const newSrttwo = state.products.filter((curItem) => curItem.id > 15);
      return {
        ...state,
        filterproducts: newSrttwo
      }


    case "ADD_CART":

      const newPropertyName = 'amountt';
      const newPropertyValue = 1;
      action.payload[newPropertyName] = newPropertyValue;

      let existingProduct = state.carts.find(
        (curItem) => curItem.id === action.payload.id
      );

      if (existingProduct) {
        let updatedProduct = state.carts.map((curElem) => {
          if (curElem.id === action.payload.id) {
            let newAmount = curElem.amountt + 1;

            return {
              ...curElem,
              amountt: newAmount,
            };
          } else {
            return curElem;
          }
        });
        return {
          ...state,
          carts: updatedProduct,
        };
      }


      else {
        return {
          ...state,
          carts: [...state.carts, action.payload]

        }
      }



    case "RMV_CART":
      const newData = state.carts.filter((curItem) => curItem.id !== action.payload);
      return {
        ...state,
        carts: newData
      }

    case "TOGGLE_CART":
      const newtoggle = !action.payload
      return {
        ...state,
        toggles: newtoggle
      }

    default:
      return state
  }
}