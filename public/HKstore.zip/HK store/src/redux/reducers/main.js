import { combineReducers } from "redux";
import { cartreducer } from "./reducre";

const rootred = combineReducers ({
    cartreducer
});

export default rootred;