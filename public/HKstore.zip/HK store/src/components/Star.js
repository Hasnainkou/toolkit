import React from "react";
import "./style.css"

import { BsStarHalf, BsStarFill, BsStar } from "react-icons/bs";
const Star = ({ stars, reviews }) => {
    const reatingstr = Array.from( { length: 5 }, (elem, index)=> {
let number = index + 0.5;
return (
<span key={index}>
{
stars >= index + 1 ? (<BsStarFill className="star"/>) : stars >= number ? (<BsStarHalf className="star"/>) : <BsStar className="star"/>
}

</span>
)
    } )
    return (
        <>
            <p className="starreview">{stars} {reatingstr} ({reviews} Reviews)</p></>
    );

}

export default Star;