import React from "react";
import "./style.css";
import { useFilterContext } from "../Context/Filter_context";

const FilterSection = () => {
  const { filters: { category }, sorting, updateFilterValue, all_products, clearFilters } = useFilterContext();


  // get the unique values of each property
  const getUniqueData = (data, attr) => {
    let newVal = data.map((curElem) => {
      return curElem[attr];
    });

    return (newVal = ["all", ...new Set(newVal)]);

  };
  const categoryData = getUniqueData(all_products, "category");

  return (
    <>
      <div className="filtersectionwarper">
        <div className="sort-selection">
          <p className="shortby">Short By: </p>
          <form action="#">
            <label htmlFor="sort"></label>
            <select
              name="sort"
              id="sort"
              className="sort-selection--style"
              onClick={sorting}>
              <option value="lowest">Price: Low to High</option>
              <option value="#" disabled></option>
              <option value="highest">Price: High to Low</option>
              <option value="#" disabled></option>
              <option value="a-z">a To z</option>
              <option value="#" disabled></option>
              <option value="z-a">z To a</option>
            </select>
          </form>
        </div>
        <div className="filter-category">
          <h3>Category</h3>
          <div className="catogoryselector">
            {categoryData.map((curElem, id) => {
              return (<div   key={id}>
                <button
                  // key={id}
                  type="button"
                  name="category"
                  value={curElem}
                  className={curElem === category ? "activee" : "deactivatee"}
                  onClick={updateFilterValue}>
                  {curElem.charAt(0).toUpperCase() + curElem.slice(1)}
                </button> </div>
              );
            })}
          </div>
        </div>

        {/* Clear Button  */}

        <div className="filter-clear">
          <button className="btn-clear" onClick={clearFilters}>
            Clear Filters
          </button>
        </div>

      </div>

      {/* <button onClick={shorting}>Click Handler</button> */}
    </>

  );

}

export default FilterSection;