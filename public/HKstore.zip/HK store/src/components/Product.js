import React from "react";
import { NavLink } from "react-router-dom";
import "./style.css";
import { FiShoppingCart } from "react-icons/fi";
import Star from "./Star";

const Product = (curElemnt) => {
    const { id, price, image, description, category, title, rating } = curElemnt;

    const newPrice = price - (price / 10).toFixed(2);
    return (
        <div className="Materdiv44">
            <NavLink to={`/singleproduct/${id}`} className="Navlink44"   >
                <div className="childdiv44" id="demo1244" >
                    <div className={(price > 40 ? "off44" : "dectiva")}>20% Off</div>
                    <div className="imgdiv44">
                        <div className="imgdivproduct44">
                            <div>
                                <img src={image} alt="No Image" className="imgproducr44" /></div>
                        </div>
                        {/* <div className="addtocartdiv44" id="addtocartdivid44">
                            <p className="addtocartp44">
                                <FiShoppingCart /> Add to Cart</p>
                        </div> */}
                    </div>
                    <div className="divh544">
                        <p >{title}</p>
                    </div>

                    <div className="displcenter44">
                        <div className="flexinlinee44" >
                            <div> <p className="divprice44"> ₹{price > 40 ? price - (price / 10).toFixed(2) : price} </p> </div>
                            <div className={(price > 40 ? "divh2244" : "dectiva")}>
                                <del >M.R.P. ₹{price}</del> </div></div>

                    </div>
                    <Star stars={rating.rate} reviews={rating.count} />
                </div>
            </NavLink>
     
        </div>
    );
}

export default Product;