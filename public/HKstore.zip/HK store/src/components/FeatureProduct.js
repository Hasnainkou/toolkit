import React from "react";
import { useProductContext } from "../Context/ProductContext";
import Product from "./Product";

const FeatureProduct = () => {

    const { isLoading, isError, featureProducts } = useProductContext();
    console.log(featureProducts);
    if (isLoading) {
        return <div style={{ display: "flex", alignItems: "center", with: "200px", justifyContent: "center" }} > Data Loading    <img src="./images/Loading_icon.gif" alt="Navlinkk" style={{ width: "150px" }} /></div>
    }
    if (isError) {
        return <div style={{ display: "flex", alignItems: "center", with: "200px", justifyContent: "center" }} > Unable to fatch API, Please try after some time.   </div>
    }
    return (
        <>
         <div  className="feturemainwidth">
            {featureProducts.map((curElemnt) => {
                return <Product key={curElemnt.id} {...curElemnt} />
            })}</div>
        </>
    );
}

export default FeatureProduct;