import React, { useState } from "react";
import { useCartContext } from "../Context/cart_context";
import { FiShoppingCart } from "react-icons/fi";


const RealAddtocart = ({ product, amount }) => {

  const { addToCart } = useCartContext();

  const changetittile = () => {
    alert(` Added into Cart :  ${product.title} `);
  }
  const { id } = product;

  return (
    <div className="sgladdtocart"
      onClick={() => { addToCart(id, amount, product); changetittile(); }}
    > <span className="sglspanaddtocart">  <FiShoppingCart /></span> ADD TO CART </div>
  );
};

export default RealAddtocart;
