import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import Nav from "./Nav";
import "./style.css";
import { FiShoppingCart } from "react-icons/fi";
import { useCartContext } from "../Context/cart_context";
import { useAuth0 } from "@auth0/auth0-react";
import { AiOutlineMenu } from "react-icons/ai";
import { VscChromeClose } from "react-icons/vsc";


const Header = () => {
  const [toggle, setToggle] = useState(false);
  const { total_item } = useCartContext();
  const { loginWithRedirect, isAuthenticated, logout, user } = useAuth0();


  window.onscroll = function () {
    var nav = document.getElementById('head45');

    if (window.scrollY > 40) {
      nav.classList.add("navbar1");
    } else {
      nav.classList.remove("navbar1");
    }
  }

  return (<>
    {/* Top Nav  */}
    <div className="top">
      <div className="flex"><div style={{ paddingLeft: "0px", cursor: "default" }} className="topnav" >English</div><div className="topnav" style={{ cursor: "default" }}>USD</div></div>

      <div className="flex">
        <NavLink to="/contact" className="textdece topnav">Help </NavLink>
        <NavLink to="/contact" className="textdece topnav"> Join Us  </NavLink>
        <div onClick={() => loginWithRedirect()} style={{ paddingRight: "0px" }} className="topnav">Sign In</div></div>
    </div>
    {/* Top Nav  */}
    <div className="maincon">

      <div className="warperr" id="head45" >
        <NavLink to="/">
          <div> <img src="./images/logo.jpg" alt="HK Store" className="logo" /></div>

        </NavLink>

        <Nav />
        <div className="login">


          {isAuthenticated ? (
            <div onClick={() => logout({ returnTo: window.location.origin })} className="headerlogin"> Logout </div>
          ) : (
            <div onClick={() => loginWithRedirect()} className="headerlogin"> Log In </div>
          )}


          <div className="tatalitemincart">
            <NavLink to="/cart" className="textdec text_alon">
              <FiShoppingCart className="cartlogototal" /> <span className="tatalitemincartspan"> {total_item} </span>
            </NavLink>
          </div>
          <div className="header-three-lins" onClick={() => setToggle(!toggle)} >
            {toggle && (<VscChromeClose />
            )}
            {!toggle && (<AiOutlineMenu />
            )}

          </div>



        </div>
      </div>
    </div>
    {toggle && (
      <div className="headertoggle"> 
      <div>      <div className="navyi1">
                    <div className="header-center-li">
                        <NavLink to="/" className="textdec3" onClick={() => setToggle(!toggle)}>
                            Home
                        </NavLink>
                    </div>
                    <div className="header-center-li">
                        <NavLink to="/about"  className="textdec3" onClick={() => setToggle(!toggle)}>
                           About
                        </NavLink>
                    </div>
                    <div className="header-center-li">
                        <NavLink to="/products"  className="textdec3" onClick={() => setToggle(!toggle)}>
                           Products
                        </NavLink>
                    </div>
                    <div className="header-center-li">
                        <NavLink to="/contact"  className="textdec3" onClick={() => setToggle(!toggle)}>
                            Contact
                        </NavLink>
                    </div>
                  
                </div>
                </div>

<div className="header-toggle-button">
      {isAuthenticated ? (
            <div onClick={() => logout({ returnTo: window.location.origin })} className="headerlogin1"> Logout </div>
          ) : (
            <div onClick={() => loginWithRedirect()} className="headerlogin1"> Log In </div>
          )}

</div>
      
      </div>
    )}







  </>
  );
};

export default Header;
