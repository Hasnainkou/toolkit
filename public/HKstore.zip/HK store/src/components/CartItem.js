import React from "react";
// import FormatPrice from "../Helpers/FormatPrice";
import { FaTrash } from "react-icons/fa";
import { useCartContext } from "../Context/cart_context";
import Cartamounttoggle from "./Cartamounttoggle";
import FormatPrice from "./FormatPrice";

const CartItem = ({ id, title, price, amount, image }) => {
  const { removeItem, setDecrease, setIncrement } = useCartContext();

  const myStyle = {
    backgroundImage:
      `url(${image})`,
    backgroundSize: "contain",
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
  };

  return (<div className="cartItemwarperdiv" >
    <div className="cartItemmasterdiv">
      <div className="cartItemimgdiv" style={myStyle}>
      </div>
      <div className="cartItemtitlediv">  {title} </div>
      <div className="cartItempricediv"> <div className="cart-price" > Price:  </div>    <FormatPrice price={price} /></div>
      <div className="cartItemamountdiv">
        {/* Quantity  */}
        <Cartamounttoggle
          amount={amount}
          setDecrease={() => setDecrease(id)}
          setIncrease={() => setIncrement(id)}
        />
      </div>

      <div className="cartItemSubtotaldiv"> <div className="cart-price" >  Item Total:  </div>  <FormatPrice price={price * amount} /> </div>

      <div className="cartItemremovediv"> <FaTrash className="remove_icon" onClick={() => removeItem(id)} /></div>
    </div>
  </div>
  );
};

export default CartItem;
