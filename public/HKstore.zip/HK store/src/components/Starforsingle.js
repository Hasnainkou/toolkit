import React from "react";
import "./style.css"

import { BsStarHalf, BsStarFill, BsStar } from "react-icons/bs";
const Starforsingle = ({ star, reviewss }) => {
    const reatingstr = Array.from( { length: 5 }, (elem, index)=> {
let number = index + 0.5;
return (
<span key={index}>
{
star >= index + 1 ? (<BsStarFill className="star"/>) : star >= number ? (<BsStarHalf className="star"/>) : <BsStar className="star"/>
}

</span>
)
    } )
    return (
        <>
            <p className="sglstarreview">{star} {reatingstr} ({reviewss} Reviews)</p></>
    );

}

export default Starforsingle;