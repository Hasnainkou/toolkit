import React from "react";
import { NavLink } from "react-router-dom";

import "./style.css";

const Nav = () => {
    return (
        <>
            <div className="navdisplay">
                <ul className="navyi">
                    <li>
                        <NavLink to="/" className="textdec">
                            Home
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/about"  className="textdec">
                           About
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/products"  className="textdec">
                           Products
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/contact"  className="textdec">
                            Contact
                        </NavLink>
                    </li>
                  
                </ul>

            </div>

        </>

    );
}

export default Nav;