import React from "react";
import "./style.css";


const ProductList = () => {
    
return (
<>
<div className="ProductListwarper">
    GOD is great
</div>


</>

);

}

export default ProductList;