import React from "react";
import "./style.css";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";

const Cartamounttoggle = ({amount, setDecrease, setIncrease}) => {
return(
<>
<div className="crtamtwarper">
<div className="crtamtdecrese"onClick={() => setDecrease()}><AiOutlineMinus/> </div>
<div className="crtamtamout"> {amount} </div>
<div className="crtamtincrease" onClick={() => setIncrease()}> <AiOutlinePlus/> </div>
</div>



</>

);

}

export default Cartamounttoggle;