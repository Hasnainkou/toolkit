import React from "react";
import { NavLink } from "react-router-dom";
import { BsBoxArrowInRight } from "react-icons/bs";
import { useCartContext } from "../Context/cart_context";


const AddToCart = ({ product, amount }) => {
const {addToCart} = useCartContext();
console.log(product)
const { id , image } = product;

  return ( 
    <NavLink to="/Cart" className="sglnavlink" 
  onClick={() => addToCart(id, amount, product , image)}
    >
    <div className="sglbutnow"> <span className="sglspanbuynow">
        < BsBoxArrowInRight />
         </span>  BUY NOW</div>
</NavLink>
  );
};


export default AddToCart;
