
import React from "react";
import { useCartContext } from "./Context/cart_context";
import CartItem from "./components/CartItem";
import { NavLink } from "react-router-dom";
import "./cssstyle.css";
import FormatPrice from "./components/FormatPrice";

const Cart = () => {
  const { cart, clearCart, total_price, shipping_fee } = useCartContext();


  // const newtotalprice = total_price.toFixed(2);
  const newsubtotal = total_price + 40;

  if (cart.length === 0) {
    return (
      <div className="noitemincart"> <div>
        <h3 className="noitemincarttext">No Item in Cart </h3> <div>
          <NavLink to="/products" className="Navlink contiuneshpingcart">Continue Shopping</NavLink></div></div>
      </div>
    );
  }

  return (
    <>
   
      <div className="cartitemborderdown">
        {cart.map((curelm) => {
          return <CartItem key={curelm.id} {...curelm} />
        })}
      </div>

      <div className="cartcontinueshopwarper">
        <div className="continueandclearcart">
          <div className="cartcontinue">  <NavLink to="/products" className="cartcontinueshop">Continue Shoping </NavLink></div>
          {/* <div className="clearcart" onClick={clearCart}>   <h2>     Clear Cart </h2> </div> */}
          <div className="filter-clear">
            <button className="btn-clear" onClick={clearCart}>
              Clear Cart
            </button>
          </div>
        </div>
      </div>
      {/* Subtotal div  */}
      <div className="cartsubtotalwarper">
        <div className="cartsubtotalmasterdiv">
          <div className="cartsubtotallast">
            <div className="subtotal"> <div> Total Price: </div> <div> <b> <FormatPrice  price={total_price} /></b>  </div>
            </div>
            <div className="subtotal hrline"> <div> Shipping Fee: </div> <div> <b> ₹{shipping_fee}</b></div>
            </div>
            <div className="subtotal ordertotalpad">
              <div>Order total:   </div> <div> <b><FormatPrice price={shipping_fee + total_price} /> </b> </div>
            </div>
          </div>
        </div>
      </div>
      {/* Subtotal div  */}
    </>);
};

export default Cart;
